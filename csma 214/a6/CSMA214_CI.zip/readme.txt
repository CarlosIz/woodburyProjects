CSMA214 Carlos Izaguirre

----controls----

move: ARROW KEYS | WASD
jump: SPACE | W | UP_ARROW
super jump: SHIFT + SPACE
attack: Q | E
restart: R
