﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TerrainTexture : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        GameObject terrain = GameObject.Find("Terrain");
        TerrainGenerator terrainGenerator = terrain.GetComponent<TerrainGenerator>();

        int depth = terrainGenerator.depth; 

        if (depth < 15)
        {
            print("dirt");
        }
        else if (depth > 15 && depth < 25)
        {
            print("stone");
        }
        else if (depth > 25)
        {
            print("snow");
        }
    }
}
